import React, { useState } from "react";
import axios from "axios";
import './App.css';

function App() {
  const [phonenumber, setPhonenumber] = useState("");
  const [headerPhoneNumber, setHeaderPhoneNumber] = useState("");
  const [message, setMessage] = useState("");

  const submitPhoneNumber = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://localhost:5000/api/post-phone",
        { phonenumber },
        { headers: { "Content-Type": "application/json" } }
      );

      const phoneNumberInHeader = response.headers["x-phone-number"];
      setHeaderPhoneNumber(phoneNumberInHeader || "Not found");

      setPhonenumber("");
      setMessage("Phone number successfully posted.");
    } catch (error) {
      console.error("Error posting phone number:", error);
      setMessage("Error posting phone number");
    }
  };

  return (
    <div className="App">
      <h1>Post Phone Number and Retrieve Header</h1>
      <form onSubmit={submitPhoneNumber}>
        <label>
          Phone Number:
          <input
            type="text"
            value={phonenumber}
            onChange={(e) => setPhonenumber(e.target.value)}
          />
        </label>
        <button type="submit">Submit Phone Number</button>
      </form>

      {message && (
        <div>
          <h2>{message}</h2>
        </div>
      )}

      {headerPhoneNumber && (
        <div>
          <h2>Phone Number from Header:</h2>
          <p>{headerPhoneNumber}</p>
        </div>
      )}
    </div>
  );
}

export default App;
