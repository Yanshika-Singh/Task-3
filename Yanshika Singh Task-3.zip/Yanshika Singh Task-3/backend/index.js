const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
app.use(express.json());

app.use(cors({
  origin: 'http://localhost:5173',
  methods: 'GET,POST',
  allowedHeaders: ['Content-Type'],
  exposedHeaders: ['X-Phone-Number']
}));

const API_URL = 'https://chimpu.online/api/post.php';

app.post('/api/post-phone', async (req, res) => {
  const { phonenumber } = req.body;

  try {
    const response = await axios.post(API_URL, `phonenumber=${phonenumber}`, {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    });

    res.set('X-Phone-Number', phonenumber);
    console.log(`Phone number sent: ${phonenumber}`);

    res.status(200).json({ message: 'Phone number successfully posted' });
  } catch (error) {
    console.error('Error posting phone number:', error);
    res.status(500).json({ error: 'Failed to post phone number' });
  }
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
